#include "array.h"

// main function for non-test code
// This exists solely for the benefit of the students to test their own code
int main() { printf("Hello, World\n"); }
