#ifndef GPA_H
#define GPA_H

#include <stdio.h>

struct person {
  char name[20];
  int age;
  double GPA;
};


#endif
