#include <gtest/gtest.h>
// needed to access the C code
extern "C" {
#include "event.h"
}

// This class definition is required by Google Test.
// See the documentation for further details.
class event_test : public ::testing::Test {
 protected:
  // Constructor runs before each test
  event_test() {}
  // Destructor cleans up after tests
  virtual ~event_test() {}
  // Sets up before each test (after constructor)
  virtual void SetUp() {}
  // Clean up after each test (before destructor)
  virtual void TearDown() {}
};

TEST(event_test, causality_holds) {
  EXPECT_TRUE(1) << "Kudos if you can actually trigger this message\n";
  EXPECT_FALSE(0) << "Kudos if you can actually trigger this message\n";
}

TEST(event_test, struct_defined) {
  struct Time t;
  struct Event e;

  // using t to avoid warning
  EXPECT_EQ(&t, &t) << "If Time struct isn't defined, you should just have a "
                       "compilation failure\n";
  EXPECT_EQ(&e, &e) << "If Event struct isn't defined, you should just have a "
                       "compilation failure\n";
}

// I may be being too transparent. We could randomise input
TEST(event_test, create_time_and_getters_work) {
  struct Event e = create_new_event(3, 14, 15, 1);
  struct Time t = get_event_time(e);

  EXPECT_EQ(get_event_id(e), 1)
      << "Error in either create_time or get_hour:\n"
      << "For t = create_time(3,14,15), get_event_id(e) should have returned "
         "3, but returned "
      << t.hour << "\n";
  EXPECT_EQ(t.hour, 3) << "Error in either create_time or get_hour:\n"
                       << "For t = create_time(3,14,15), t.hour should have "
                          "returned 14, but returned "
                       << t.hour << "\n";
  EXPECT_EQ(t.min, 14) << "Error in either create_time or get_hour:\n"
                       << "For t = create_time(3,14,15), t.min should have "
                          "returned 15, but returned "
                       << t.min << "\n";
  EXPECT_EQ(t.sec, 15) << "Error in either create_time or get_hour:\n"
                       << "For t = create_time(3,14,15), t.sec should have "
                          "returned 15, but returned "
                       << t.sec << "\n";
}

TEST(event_test, elapsed_time_base) {
  struct Event e1 = create_new_event(2, 34, 10, 0);
  struct Event e2 = create_new_event(5, 43, 22, 2);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 3) << "Error in elapsed_time:\n"
                        << "For dt = elapsed_time(2:34:10, 5:43:22), "
                           "get_hour(dt) should have returned 3, but returned "
                        << dt.hour << "\n";
  EXPECT_EQ(dt.min, 9) << "Error in either create_time or get_hour:\n"
                       << "For dt = elapsed_time(2:34:10, 5:43:22), "
                          "get_min(dt) should have returned 9, but returned "
                       << dt.min << "\n";
  EXPECT_EQ(dt.sec, 12) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(2:34:10, 5:43:22), "
                           "get_sec(dt) should have returned 12, but returned "
                        << dt.sec << "\n";
}

TEST(event_test, elapsed_time_sec_from_min) {
  struct Event e1 = create_new_event(2, 34, 22, 3);
  struct Event e2 = create_new_event(5, 43, 10, 4);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 3) << "Error in elapsed_time:\n"
                        << "For dt = elapsed_time(2:34:22, 5:43:10), "
                           "get_hour(dt) should have returned 3, but returned "
                        << dt.hour << "\n";
  EXPECT_EQ(dt.min, 8) << "Error in either create_time or get_hour:\n"
                       << "For dt = elapsed_time(2:34:22, 5:43:10), "
                          "get_min(dt) should have returned 8, but returned "
                       << dt.min << "\n";
  EXPECT_EQ(dt.sec, 48) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(2:34:22, 5:43:10), "
                           "get_sec(dt) should have returned 48, but returned "
                        << dt.sec << "\n";
}

TEST(event_test, elapsed_time_min_from_hour) {
  struct Event e1 = create_new_event(2, 43, 10, 5);
  struct Event e2 = create_new_event(5, 34, 22, 6);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 2) << "Error in elapsed_time:\n"
                        << "For dt = elapsed_time(2:43:10, 5:34:22), "
                           "get_hour(dt) should have returned 2, but returned "
                        << dt.hour << "\n";
  EXPECT_EQ(dt.min, 51) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(2:43:10, 5:34:22), "
                           "get_min(dt) should have returned 51, but returned "
                        << dt.min << "\n";
  EXPECT_EQ(dt.sec, 12) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(2:43:10, 5:34:22), "
                           "get_sec(dt) should have returned 12, but returned "
                        << dt.sec << "\n";
}

TEST(event_test, elapsed_time_sec_from_hour) {
  struct Event e1 = create_new_event(2, 27, 22, 7);
  struct Event e2 = create_new_event(5, 27, 10, 8);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 2) << "Error in elapsed_time:\n"
                        << "For dt = elapsed_time(2:27:22, 5:27:10), dt.hour "
                           "should have returned 2, but returned "
                        << dt.hour << "\n";
  EXPECT_EQ(dt.min, 59) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(2:27:22, 5:27:10), dt.min "
                           "should have returned 59, but returned "
                        << dt.min << "\n";
  EXPECT_EQ(dt.sec, 48) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(2:27:22, 5:27:10), dt.sec "
                           "should have returned 48, but returned "
                        << dt.sec << "\n";
}

TEST(event_test, elapsed_time_first_event_hour_later) {
  struct Event e1 = create_new_event(23, 34, 10, 9);
  struct Event e2 = create_new_event(2, 43, 22, 10);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 20) << "Error in elapsed_time:\n"
                         << "For dt = elapsed_time(5:34:10, 2:43:22), dt.hour "
                            "should have returned 20, but returned "
                         << dt.hour << "\n";
  EXPECT_EQ(dt.min, 50) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(5:34:10, 2:43:22), dt.min "
                           "should have returned 50, but returned "
                        << dt.min << "\n";
  EXPECT_EQ(dt.sec, 48) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(5:34:10, 2:43:22), dt.sec "
                           "should have returned 48, but returned "
                        << dt.sec << "\n";
}

TEST(event_test, elapsed_time_first_event_min_later) {
  struct Event e1 = create_new_event(5, 43, 10, 11);
  struct Event e2 = create_new_event(5, 34, 22, 12);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 0) << "Error in elapsed_time:\n"
                        << "For dt = elapsed_time(5:43:10, 5:34:22), dt.hour "
                           "should have returned 0, but returned "
                        << dt.hour << "\n";
  EXPECT_EQ(dt.min, 8) << "Error in either create_time or get_hour:\n"
                       << "For dt = elapsed_time(5:43:10, 5:34:22), dt.min "
                          "should have returned 8, but returned "
                       << dt.min << "\n";
  EXPECT_EQ(dt.sec, 48) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(5:43:10, 5:34:22), dt.sec "
                           "should have returned 48, but returned "
                        << dt.sec << "\n";
}

TEST(event_test, elapsed_time_first_event_sec_later) {
  struct Event e1 = create_new_event(5, 27, 22, 13);
  struct Event e2 = create_new_event(5, 27, 10, 14);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 0) << "Error in elapsed_time:\n"
                        << "For dt = elapsed_time(5:27:22, 5:27:10), dt.hour "
                           "should have returned 0, but returned "
                        << dt.hour << "\n";
  EXPECT_EQ(dt.min, 0) << "Error in either create_time or get_hour:\n"
                       << "For dt = elapsed_time(5:27:22, 5:27:10), dt.min "
                          "should have returned 0, but returned "
                       << dt.min << "\n";
  EXPECT_EQ(dt.sec, 12) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(5:27:22, 5:27:10), dt.sec "
                           "should have returned 12, but returned "
                        << dt.sec << "\n";
}

TEST(event_test, elapsed_time_same_time) {
  struct Event e1 = create_new_event(5, 27, 22, 15);
  struct Event e2 = create_new_event(5, 27, 22, 16);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 0) << "Error in elapsed_time:\n"
                        << "For dt = elapsed_time(5:27:22, 5:27:22), dt.hour "
                           "should have returned 0, but returned "
                        << dt.hour << "\n";
  EXPECT_EQ(dt.min, 0) << "Error in either create_time or get_hour:\n"
                       << "For dt = elapsed_time(5:27:22, 5:27:22), dt.min "
                          "should have returned 0, but returned "
                       << dt.min << "\n";
  EXPECT_EQ(dt.sec, 0) << "Error in either create_time or get_hour:\n"
                       << "For dt = elapsed_time(5:27:22, 5:27:22), dt.sec "
                          "should have returned 0, but returned "
                       << dt.sec << "\n";
}

TEST(event_test, elapsed_time_finale) {
  struct Event e1 = create_new_event(5, 43, 22, 17);
  struct Event e2 = create_new_event(2, 34, 10, 18);
  struct Time dt = elapsed_time(e1, e2);

  EXPECT_EQ(dt.hour, 3) << "Error in elapsed_time:\n"
                        << "For dt = elapsed_time(5:43:22, 2:34:10), dt.hour "
                           "should have returned 3, but returned "
                        << dt.hour << "\n";
  EXPECT_EQ(dt.min, 9) << "Error in either create_time or get_hour:\n"
                       << "For dt = elapsed_time(5:43:22, 2:34:10), dt.min "
                          "should have returned 9, but returned "
                       << dt.min << "\n";
  EXPECT_EQ(dt.sec, 12) << "Error in either create_time or get_hour:\n"
                        << "For dt = elapsed_time(5:43:22, 2:34:10), dt.sec "
                           "should have returned 12, but returned "
                        << dt.sec << "\n";
}

int main(int argc, char **argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
