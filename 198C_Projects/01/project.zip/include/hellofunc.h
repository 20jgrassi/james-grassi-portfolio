#ifndef HELLOFUNC_H
#define HELLOFUNC_H

int sum(int a, int b);

#endif