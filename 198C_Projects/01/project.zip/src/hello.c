#include <stdio.h>
#include "hellofunc.h"

int main(int argc, char* argv[]) {
  printf("Hello, 198c!\n");
  printf("sum(1, 2) is %d!\n", sum(1, 2));
  return 0;
}
